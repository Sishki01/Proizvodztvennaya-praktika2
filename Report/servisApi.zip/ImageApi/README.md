# Image Processing API — Вариант 3

## Стек технологий
- **Платформа**: .NET 9.0
- **Язык**: C# 13
- **Web-фреймворк**: ASP.NET Core (контроллеры)
- **База данных**: SQLite + Entity Framework Core 9
- **Обработка изображений**: SixLabors.ImageSharp
- **Документация**: Swagger / OpenAPI

---

## Запуск проекта

```bash
# Восстановить зависимости и запустить
dotnet restore
dotnet run
```

Swagger UI откроется по адресу: **http://localhost:5000**

---

## Описание методов API

| Название | Метод | Путь | Описание |
|---|---|---|---|
| Добавление изображения | `POST` | `api/image/add` | Сохраняет запись об изображении в БД |
| Информация об изображении | `GET` | `api/image/info` | Возвращает размер, разрешение, дату создания |
| Переименование изображения | `PUT` | `api/image/change/name` | Переименовывает файл и обновляет запись в БД |
| Получить все изображения | `GET` | `api/image` | Возвращает все записи из БД |

---

## Примеры запросов

### POST api/image/add
```json
POST http://localhost:5000/api/image/add
Content-Type: application/json

{
  "filePath": "C:/images/photo.jpg"
}
```

### GET api/image/info
```
GET http://localhost:5000/api/image/info?filePath=C:/images/photo.jpg
```

**Ответ:**
```json
{
  "id": 1,
  "name": "photo",
  "sizeBytes": 204800,
  "width": 1920,
  "height": 1080,
  "type": "jpg",
  "dateAdded": "2025-03-19T10:00:00Z",
  "filePath": "C:/images/photo.jpg"
}
```

### PUT api/image/change/name
```json
PUT http://localhost:5000/api/image/change/name
Content-Type: application/json

{
  "filePath": "C:/images/photo.jpg",
  "newName": "vacation_photo"
}
```

### GET api/image
```
GET http://localhost:5000/api/image
```

---

## Структура базы данных

Таблица **Images**:

| Поле | Тип | Описание |
|---|---|---|
| Id | INTEGER | Первичный ключ |
| Name | TEXT | Наименование файла (без расширения) |
| Size | INTEGER | Размер файла в байтах |
| Width | INTEGER | Ширина изображения (px) |
| Height | INTEGER | Высота изображения (px) |
| Type | TEXT | Тип файла (png, jpg и т.д.) |
| DateAdded | TEXT | Дата добавления (UTC) |
| FilePath | TEXT | Полный путь к файлу |

База данных `images.db` создаётся автоматически в папке запуска приложения.
